//Event básicamente es un parámetro tipo objeto MouseEvent
//Su contenido se obtiene de manera automatica al desencadenarse un evento
// que almacena la información general del click dada por el navegador
//El navegador no muestre el menu de opciones por defecto.
//Con esta linea de abajo aseguramos que en caso de hacer click derecho

function manejarClick(event){
    const celda = event.currentTarget;
    if(juego.haTerminado()) return;
    //Creo una matriz llamando al algoritmo de traducción de índice unidimensional a indice bidimensional i,j
    let {fila_click, col_click} = getCoordenadas(event);

    if(event.type == "click"){
        juego.clicksIzquierdo++;  // Incrementar contador de clicks izquierdo
        juego.actualizarEstadisticasUI(); // Actualizar UI, 
        if(juego.minutos == 0 && juego.segundos == 0){
                iniciarTimer();
        }
        if (celda.classList.contains("celda-bandera")) {
                return; // Evita que se revele en caso de dar click izq a una bandera
        }
        if (juego.tablero[fila_click][col_click] == "M") { //Click en lugar donde se pierde
            celda.classList.add("celda-pulso");  //Renderizo un lienzo de pulso rojo
            setTimeout(() => {
                celda.classList.remove("celda-pulso");
            }, 700);
        }
        
        //ACTUALIZO TABLERO LÓGICO SEGÚN LA COORDENADA IMPUESTA
        setBoard(fila_click, col_click);  //Quizas podrìa mandar solo el indice 1d

        //GUARDO LA JUGADA EN UN LOG
        traza.push({
            tipo: "izquierdo",
            timestamp: Date.now(),
            chord: Number(event.target.dataset.index)  //Parseo el str a entero
        })
        //LUEGO RENDERIZO EL TABLERO:
        mapeoDOM();  //Esto renderiza los objetos que no son minas

    //----------     Verificación de fin de juego     ----------//
        if (juego.haGanado() || juego.haPerdido()) { 
            terminarJuego();
        }

    }

    else if(event.type == "contextmenu"){
        event.preventDefault(); // evitar menú o comportamiento por defecto
        juego.clicksDerecho++;
        // Hacemos un toggle Si la celda ya tiene bandera, la quitamos 
        if (celda.classList.contains("celda-bandera")) {
            celda.classList.remove("celda-bandera");
            celda.classList.add("celda-oculta");
            if (juego.minasRestantes < juego.minas) {
                juego.minasRestantes++;
            }
        } else {
            if (juego.tablero[fila_click][col_click] == "M" || juego.tablero[fila_click][col_click] == "V") {
                celda.classList.remove("celda-oculta");
                celda.classList.add("celda-bandera");
                if (juego.minasRestantes > 0) {
                    juego.minasRestantes--;
                }
            }
        }

        //GUARDO LA JUGADA EN UN LOG
        traza.push({
            tipo: "derecho",
            timestamp: Date.now(),
            chord: Number(event.target.dataset.index)  //Parseo el str a entero
        })

        juego.actualizarEstadisticasUI(); // Actualizar UI
        
    }
    return juego.celdas;

 }
function terminarJuego(){
    detenerTimer();
    juego.fechaUltimaPartida = new Date().toLocaleString();
    if (juego.estado == "ganado") { // Si revelaste todas las celdas ganas
        juego.expGanada = calcularExp(juego);
        setTimeout(() => {
            alert("Ganaste");
            // Enviar estadísticas al backend SOLO cuando gana
            if (typeof enviarStats === 'function') {  //verifica que api.js fue cargada
                enviarStats(1);    // esto envía finalmente el contenido a la función que armará el paquete post
            }
        }, 50);
    }
    else if(juego.estado == "perdido"){
        juego.expGanada = 0; // o  dejar 0 para perdida
        alert("Has perdido >:(");
        setTimeout(() => {
            // NO enviar estadísticas al backend cuando pierde
        }, 50);
    }
    juego.actualizarEstadisticasUI();
    return;
}